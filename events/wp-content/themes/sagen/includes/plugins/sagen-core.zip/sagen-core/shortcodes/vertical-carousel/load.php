<?php

include_once SAGEN_CORE_SHORTCODES_PATH.'/vertical-carousel/functions.php';
include_once SAGEN_CORE_SHORTCODES_PATH.'/vertical-carousel/vertical-carousel.php';