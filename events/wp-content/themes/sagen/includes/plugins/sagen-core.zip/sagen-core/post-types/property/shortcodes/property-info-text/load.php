<?php

require_once 'property-info-text.php';
require_once 'helper-functions.php';