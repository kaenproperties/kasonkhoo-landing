<?php

include_once SAGEN_CORE_SHORTCODES_PATH.'/title-hero-section/functions.php';
include_once SAGEN_CORE_SHORTCODES_PATH.'/title-hero-section/title-hero-section.php';