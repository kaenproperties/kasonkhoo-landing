<?php

include_once SAGEN_CORE_SHORTCODES_PATH . '/image-map-gallery/functions.php';
include_once SAGEN_CORE_SHORTCODES_PATH . '/image-map-gallery/image-map-gallery.php';