<?php

include_once SAGEN_CORE_SHORTCODES_PATH . '/anchor-menu/functions.php';
include_once SAGEN_CORE_SHORTCODES_PATH . '/anchor-menu/anchor-menu.php';
