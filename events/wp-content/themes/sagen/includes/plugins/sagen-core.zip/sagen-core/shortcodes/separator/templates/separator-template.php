<div class="qodef-separator-holder clearfix <?php echo esc_attr($holder_classes); ?>">
	<div class="qodef-separator" <?php echo sagen_select_get_inline_style($holder_styles); ?>></div>
</div>
