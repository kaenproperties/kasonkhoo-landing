<?php

require_once 'property-fullscreen-slider.php';
require_once 'helper-functions.php';