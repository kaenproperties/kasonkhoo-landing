<?php

get_header();

sagen_select_get_title();

do_action('sagen_select_before_main_content');

sagen_core_get_single_property();

get_footer();