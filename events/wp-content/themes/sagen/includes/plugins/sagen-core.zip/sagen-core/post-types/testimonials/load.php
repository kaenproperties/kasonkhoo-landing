<?php

include_once SAGEN_CORE_CPT_PATH . '/testimonials/testimonials-register.php';
include_once SAGEN_CORE_CPT_PATH . '/testimonials/helper-functions.php';