<?php

include_once SAGEN_CORE_CPT_PATH . '/property/property-register.php';
include_once SAGEN_CORE_CPT_PATH . '/property/helper-functions.php';